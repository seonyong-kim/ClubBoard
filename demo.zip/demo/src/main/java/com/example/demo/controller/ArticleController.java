package com.example.demo.controller;

import com.example.demo.dto.ArticleDetailDto;
import com.example.demo.dto.ArticleLinkDto;
import com.example.demo.dto.ArticlePreviewDto;
import com.example.demo.service.ArticleService;
import lombok.RequiredArgsConstructor;
import org.springframework.data.domain.Page;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/articles")
@RequiredArgsConstructor
public class ArticleController {
    private final ArticleService service;

    // 목록 페이지
    @GetMapping
    public Page<ArticlePreviewDto> list(@RequestParam(defaultValue = "0") int page,
                                        @RequestParam(defaultValue = "20") int size) {
        return service.getPreviews(page, size);
    }

    // 상세
    @GetMapping("/{id}")
    public ArticleDetailDto detail(@PathVariable Long id) {
        return service.getDetail(id);
    }

    // 이전 글
    @GetMapping("/{id}/prev")
    public ArticleLinkDto prev(@PathVariable Long id) {
        return service.getPrev(id);
    }

    // 다음 글
    @GetMapping("/{id}/next")
    public ArticleLinkDto next(@PathVariable Long id) {
        return service.getNext(id);
    }
}
