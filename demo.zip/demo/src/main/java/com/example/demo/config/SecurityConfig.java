package com.example.demo.config;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.security.config.Customizer;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.config.annotation.web.configurers.AbstractHttpConfigurer;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.security.web.SecurityFilterChain;
import org.springframework.security.web.authentication.HttpStatusEntryPoint;
import org.springframework.web.cors.CorsConfiguration;
import org.springframework.web.cors.CorsConfigurationSource;
import org.springframework.web.cors.UrlBasedCorsConfigurationSource;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.config.annotation.authentication.configuration.AuthenticationConfiguration;

import java.util.List;


@Configuration
@EnableWebSecurity
public class SecurityConfig {

    @Bean
    public SecurityFilterChain securityFilterChain(HttpSecurity http) throws Exception {
        http
                // SPA + JSON 로그인: /api/** 는 CSRF 예외(쿠키-세션 사용)
                .csrf(csrf -> csrf.ignoringRequestMatchers("/api/**"))
                .cors(Customizer.withDefaults())
                .httpBasic(AbstractHttpConfigurer::disable)
                // React에서 로그인하므로 폼로그인 비활성화
                .formLogin(AbstractHttpConfigurer::disable)

                // /api/** 에 한해서 미인증이면 401(JSON) 응답
                .exceptionHandling(e -> e
                        .defaultAuthenticationEntryPointFor(
                                new HttpStatusEntryPoint(HttpStatus.UNAUTHORIZED),
                                req -> {
                                    String uri = req.getRequestURI();
                                    return uri != null && uri.startsWith("/api/");
                                }
                        )
                )

                .authorizeHttpRequests(auth -> auth
                        // 1) 인증/상태 조회 API 먼저 허용 (순서 중요)
                        .requestMatchers(HttpMethod.POST, "/api/auth/login").permitAll()
                        .requestMatchers(HttpMethod.GET,  "/api/auth/me").permitAll()
                        // 로그아웃은 인증 필요
                        .requestMatchers(HttpMethod.POST, "/api/auth/logout").authenticated()
                        .requestMatchers(HttpMethod.POST, "/api/debug/check").permitAll()
                        // 2) (선택) 읽기 공개 API가 있다면 허용
                        .requestMatchers(HttpMethod.GET, "/api/**").permitAll()
                        .requestMatchers(org.springframework.http.HttpMethod.POST, "/api/debug/set", "/api/debug/check").permitAll()


                        // 3) 그 외 /api/** 는 인증 필요 — 반드시 위 허용 규칙 뒤에 둬야 함
                        .requestMatchers("/api/**").authenticated()

                        // 4) 정적/기타 리소스
                        .requestMatchers("/", "/health",
                                "/favicon.ico", "/css/**", "/js/**", "/images/**").permitAll()
                        .requestMatchers("/actuator/health", "/actuator/info").permitAll()
                        .requestMatchers("/actuator/**").hasRole("ADMIN")

                        // SSR 페이지가 사실상 없다면 널널하게:
                        .anyRequest().permitAll()
                );

        return http.build();
    }

    @Bean
    public PasswordEncoder passwordEncoder() {
        return new BCryptPasswordEncoder();
    }

    @Bean
    public CorsConfigurationSource corsConfigurationSource() {
        CorsConfiguration cfg = new CorsConfiguration();
        cfg.setAllowedOrigins(List.of("*"));
        cfg.setAllowedMethods(List.of("GET","POST","PUT","PATCH","DELETE","OPTIONS"));
        cfg.setAllowedHeaders(List.of("*"));
        cfg.setAllowCredentials(false);
        UrlBasedCorsConfigurationSource source = new UrlBasedCorsConfigurationSource();
        source.registerCorsConfiguration("/**", cfg);
        return source;
    }

    @Bean
    public AuthenticationManager authenticationManager(AuthenticationConfiguration configuration) throws Exception {
        // UserDetailsService + PasswordEncoder 기반으로 표준 AuthenticationManager를 만들어서 노출
        return configuration.getAuthenticationManager();
    }
}

